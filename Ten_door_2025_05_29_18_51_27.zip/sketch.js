function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let circleX, circleY, circleSize;
let score = 0;
let misses = 0;
let timeLeft = 60; // segundos
let gameOver = false;

function setup() {
  createCanvas(400, 400);
  newCircle();
  frameRate(60);
  setInterval(() => {
    if (!gameOver) {
      timeLeft--;
      if (timeLeft <= 0) {
        gameOver = true;
      }
    }
  }, 1000);
}

function draw() {
  background(50);

  if (gameOver) {
    fill(255, 0, 0);
    textAlign(CENTER, CENTER);
    textSize(32);
    text('Game Over!', width / 2, height / 2 - 30);
    textSize(20);
    text('Pontuação: ' + score, width / 2, height / 2 + 10);
    return;
  }

  fill(0, 255, 100);
  ellipse(circleX, circleY, circleSize);

  fill(255);
  textSize(16);
  textAlign(LEFT, TOP);
  text('Pontos: ' + score, 10, 10);
  text('Erros: ' + misses, 10, 30);
  text('Tempo: ' + timeLeft, 10, 50);
}

function mousePressed() {
  let d = dist(mouseX, mouseY, circleX, circleY);
  if (d < circleSize / 2) {
    score++;
    newCircle();
  } else {
    misses++;
    if (misses >= 5) {
      gameOver = true;
    }
  }
}

function newCircle() {
  circleSize = random(30, 60);
  circleX = random(circleSize / 2, width - circleSize / 2);
  circleY = random(circleSize / 2, height - circleSize / 2);
}

